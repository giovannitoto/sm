#CODICE ELABORATO FINALE
#Libreria

library(TextWiller)
library(dplyr)
library(stringr)
library(quanteda)
library(tidyverse)
library(tidytext)
library(topicmodels)
library(ggplot2)
library(tm)
library(quanteda.textstats)
library(quanteda.textmodels)
library(tidygraph) 
library(ggraph)
library(Matrix)
library(igraph)
library(FactoMineR)
library(factoextra)
library(cluster)  # AGNES, DIANA
library(xtable)
require(gridExtra)
require(grid)
require(gtable)

# ---------------------------------------------------------------------------- #

# Rimozione delle colonne non necessarie.

# ---------------------------------------------------------------------------- #

rm(list=ls())
tw <- read.csv("data/00_tweets.csv", sep="\t", encoding="UTF-8")
tw <- tw[tw$language=="it",]

# ---------------------------------------------------------------------------- #

# rimuovo lingua poiche' considero solo quelli italiani (it)
tw$language <- NULL
# rimuovo id del tweet
tw$X.U.FEFF.id <- NULL
# rimuovo id della conversazione (99409 modalita')
tw$conversation_id <- NULL
# created_at non so cosa voglia dire (immagino sia una conversione numerica
# della data di creazione)
tw$created_at <- NULL
# rimuovo timezone poiche' sempre la stessa, ovvero 200
tw$timezone <- NULL
# rimuovo luogo poiche' disponibile per una sola osservazione
tw$place <- NULL
# user_id, user_id_str, username e name sono in corrispondenza univoca: mantengo
# solo l'username
tw$user_id <- NULL
tw$user_id_str <- NULL
tw$name <- NULL
# creo variabile che mi dice se il tweet contiene un link esterno oppure no
tw$urls[tw$urls=="[]"] <- 0
tw$urls[tw$urls!=0] <- 1
# rimuovo link diretto del post
tw$link <- NULL
# non so cosa sia ma ha solo valori nulli
tw$cashtags <- NULL
# photos e' la lista degli url delle foto del tweet; presenza/assenza di url
# e' contenuta nella var 'video'
tw$photos <- NULL
tw$thumbnail <- NULL
# non ci sono retweet, ergo variabili legate sono inutili
tw$retweet <- NULL
tw$retweet_id <- NULL
tw$retweet_date <- NULL
tw$user_rt <- NULL
tw$user_rt_id <- NULL
# variabili relative a traduzione sono vuote
tw$trans_dest <- NULL
tw$trans_src <- NULL
tw$translate <- NULL
# altre variabili nulle
tw$near <- NULL
tw$geo <- NULL
tw$source <- NULL
tw$search <- NULL
# creo variabile presenza/assenza di una citazione (quote) nel tweet
tw$quote_url[tw$quote_url==""] <- 0
tw$quote_url[tw$quote_url!=0] <- 1
# creo variabile risposta/non risposta ad un altro tweet
tw$reply_to[tw$reply_to=="[]"] <- 0
tw$reply_to[tw$reply_to!=0] <- 1

# converto la variabile 'hashtags' in testo per renderla analizzabile
tw$hashtags <- gsub("\\[|\\]|'|,", "", tw$hashtags)
# calcolo il numero di hashtag presente in ogni tweet
htags_count <- strsplit(tw$hashtags, " ")
htags_count <- lapply(htags_count, trimws)
htags_count <- lapply(htags_count, length)
htags_count <- unlist(htags_count)
tw$hashtags_count <- htags_count
# conto il numero di caratteri
tw$tweet_nchar <- nchar(tw$tweet)

# ---------------------------------------------------------------------------- #

save(tw, file="data/01_tweets.RData")

# ---------------------------------------------------------------------------- #

# Pulizia dei tweet; i tweet non in italiano sono scartati.

# ---------------------------------------------------------------------------- #

rm(list=ls())
load("data/01_tweets.RData")
# creo colonna in cui salvare il tweet originale
tw$tweet_original <- tw$tweet
# aggiungo colonna con gli stem 
tw$tweet_stem <- NA

# ---------------------------------------------------------------------------- #

# Importo la lista delle stopwords, che verra' utilizzata all'interno del ciclo
stop_words <- read.table("data/stopwords-it.txt", encoding="UTF-8",
                         quote="\"", comment.char="")$V1
stop_words <- paste(stop_words, collapse = '\\b|\\b')
stop_words <- paste0('\\b', stop_words, '\\b')

# Ottengo lista delle emote
emote_list <- tw$tweet %>% str_match_all("\\bemote_\\w+-?\\w+\\b") %>% unlist %>% unique
emote_list <- emote_list[order(nchar(emote_list),decreasing=T)]
# Sostituisco eventuali "-" con "_"
emote_list_fix <- emote_list %>% stringr::str_replace_all(pattern="-", replacement="_") %>% unlist
for (ei in 1:length(emote_list)) {
  tw$tweet <- stringr::str_replace_all(string=tw$tweet,
                                       pattern=paste("\\b",emote_list_fix[ei],"\\b",sep=""),
                                       replacement=emote_list[ei])
}
# Ottengo lista di emote modificate in modo da non essere influenzate dallo stemming
emote_list <- emote_list_fix
emote_list_fix <- paste("zzz", emote_list, "zzz", sep="")

# Uso delle RegEx per identificare e rimuovere unicode
UNICODE <- c("u[0-9]{4}[0-9A-Fa-f]{4}", "u[0-9]{4}")

# ---------------------------------------------------------------------------- #
# Importo la lista delle parole da considerare come singole entita'
# words_to_merge <- read.delim("data/words_to_merge.txt", header=F)$V1
# words_to_merge <- sapply(words_to_merge, function(x) paste("\\b",x,"\\b",sep=""))
# words_to_merge <- words_to_merge[order(nchar(words_to_merge),decreasing=T)]
# ---------------------------------------------------------------------------- #

# Il ciclo e' inefficiente ma serve per capire a che punto e' il procedimento.
for(i in unique(tw$partito)){
  cat(i, "\n", sep="")
  for(j in unique(tw$username[tw$partito==i])){
    cat(j, ", ", sep="")
    tt <- tw[tw$username == j,]
    # Tengo solo testo del tweet, username, partito e creo indice di riga
    tt <- tt %>% select(tweet, username=username, partito=partito) %>% mutate(id = 1:n())
    # Utilizzo la funzione normalizzaTesti che rende confrontabili i tweet
    # normalizzando url, caratteri speciali, emoticons, punteggiatura, ...
    tt$tweet <- normalizzaTesti(tt$tweet,
                                tolower = TRUE,
                                normalizzahtml = TRUE,
                                normalizzacaratteri = TRUE,
                                normalizzaemote = TRUE,
                                normalizzaEmoticons = TRUE,
                                normalizzapunteggiatura = TRUE,
                                normalizzaslang = TRUE,
                                fixed = TRUE,
                                perl = TRUE,
                                preprocessingEncoding = TRUE,
                                encoding = "UTF-8",
                                sub = "",
                                contaStringhe = c("\\?", "\\!", "@", "#",
                                                  "(\200|euro)", "(\\$|dollar)",
                                                  "SUPPRESSEDTEXT"),
                                suppressInvalidTexts = TRUE,
                                verbatim = TRUE,
                                remove = FALSE,
                                removeUnderscore = FALSE)
    # Rimuovo url, che sono codificati con la stringa "wwwurlwww" da normalizzaTesti
    tt$tweet <- str_remove(tt$tweet, "wwwurlwww")
    
    # ------------------------------------------------------------------------ #
    # Considero come alcuni gruppi di parole come singole entita'; a livello
    # pratico, unisco le parole sostituendo gli spazi con "_"
    #for (w in words_to_merge) {
    #  tt$tweet <- str_replace_all(tt$tweet, w, str_replace_all(w," ","_"))
    #}
    # ------------------------------------------------------------------------ #
    
    # Utilizzo le stopwords contenute in "stopword-it.txt" per rimuovere le
    # parole non utili per l'analisi del testo.
    tt$tweet <- stringr::str_replace_all(tt$tweet, stop_words, "")
    # Tolgo delle sequenze particolari di caratteri:
    #  - 'aggiornamento #', dove # e' un numero (regex: \d+)
    #  - parole unicamente composte da cifre
    tt$tweet <- str_remove(tt$tweet, "aggiornamento \\d+")
    tt$tweet <- gsub("\\b[0-9\\W]+\\b", "", tt$tweet)
    # Rimuovo unicode
    for (unicode_pattern in UNICODE) {
      unicode_to_remove <- tt$tweet %>% str_match_all(unicode_pattern) %>% unlist %>% unique
      unicode_to_remove <- unicode_to_remove[order(nchar(unicode_to_remove),decreasing=T)]
      unicode_to_remove <- paste0('\\b', paste(unicode_to_remove, collapse='\\b|\\b'), '\\b')
      tt$tweet <- stringr::str_replace_all(tt$tweet, unicode_to_remove, "")
    }
    # Rimuovo '\'
    tt$tweet <- gsub("\\\\", "", tt$tweet)
    # Sostituisco spazi multipli con un singolo spazio
    tt$tweet <- str_squish(tt$tweet)
    # ------------------------------------------------------------------------ #
    # Sostituisco i tweet originali con i nuovi tweet normalizzati
    tw$tweet[tw$username==j] <- tt$tweet
    # ------------------------------------------------------------------------ #
    # Modifico le emote in modo che lo stemming non le possa modificare
    for (ei in 1:length(emote_list)) {
      tt$tweet <- stringr::str_replace_all(string=tt$tweet,
                                           pattern=paste("\\b",emote_list[ei],"\\b",sep=""),
                                           replacement=emote_list_fix[ei])
    }
    # Applico stemming
    tt$tweet <- sapply(str_split(tt$tweet," "),
                       function(x) paste(char_wordstem(x,language="ita"),collapse=" "))
    # Ritorno le emote alla forma originale
    for (ei in 1:length(emote_list)) {
      tt$tweet <- stringr::str_replace_all(string=tt$tweet,
                                           pattern=paste("\\b",emote_list_fix[ei],"\\b",sep=""),
                                           replacement=emote_list[ei])
    }
    # ------------------------------------------------------------------------ #
    # Sostituisco i tweet originali con i nuovi tweet normalizzati (stemming)
    tw$tweet_stem[tw$username==j] <- tt$tweet
    # ------------------------------------------------------------------------ #
  }
  cat("\n")
}

# ---------------------------------------------------------------------------- #

save(tw, file="data/02_tweets_stem.RData")

# ---------------------------------------------------------------------------- #

# Pulizia dei tweet con caratteri anomali.

# ---------------------------------------------------------------------------- #

rm(list=ls())
load("data/02_tweets_stem.RData")
# Considero solo i tweet originali, non le risposte ad altri tweet
tw <- tw[tw$reply_to==0,]

# per rendere identicabili i tweet, aggiungo la colonna id
tw$id <- 1:nrow(tw)
# metto la colonna in posizione 1
tw <- tw[, c(19,2:18)]


# ---------------------------------------------------------------------------- #

REGEX8 <- "u[0-9]{4}[0-9A-Fa-f]{4}"
REGEX4 <- "u[0-9]{4}"

REGEX <- REGEX4

sum(str_detect(tw$tweet,REGEX))
tw_to_check <- which(str_detect(tw$tweet,REGEX))
# Ottengo lista degli unicode ancora presenti nei tweet puliti
unicode_to_remove <- tw$tweet[tw_to_check] %>% str_match_all(REGEX) %>% unlist %>% unique %>% sort

for (w in unicode_to_remove) {
  tw$tweet2 <- str_remove(tw$tweet, w)
  cat(w, " ")
}

for (i in tw_to_check) {
  cat("Autore:", tw$username[i], "-", tw$partito[i], "\n")
  print(tw$tweet[i])
  print(tw$tweet2[i])
  cat(tw$tweet_original[i], "\n\n")
}

# ---------------------------------------------------------------------------- #

# Analisi esplorative varie:
#  - rimozione stem troppo rari e/o comuni

# ---------------------------------------------------------------------------- #

rm(list=ls())
load("data/02_tweets_stem.RData")

# ---------------------------------------------------------------------------- #

for (part in unique(tw$partito)) {
  tmp_tw <- tw[tw$partito==part,]
  cat(part, "\n")
  cat("Numero tweet:", nrow(tmp_tw), "\n")
  cat("Numero tweet risposta:", nrow(tmp_tw[tmp_tw$reply_to==1,]), "\n")
  cat("% tweet risposta:", mean(tmp_tw$reply_to==1), "\n")
  # contenuti non testuali (link esterni, img, video)
  cat("\n")
  cat("% tweet con immagini e/o video:", mean(tmp_tw$video==1), "\n")
  cat("% tweet con link esterni:", mean(tmp_tw$urls==1), "\n")
  # like, reply, retweet totali
  cat("\n")
  cat("Numero like totali:", sum(tw$nlikes), "\n")
  cat("Numero di risposte tot. ai tweet:", sum(tmp_tw$nreplies), "\n")
  cat("Numero di retweet totali:", sum(tmp_tw$nretweets), "\n")
  # like, reply, retweet medi per tweet (per confrontare partiti)
  cat("\n")
  cat("Numero di like medi a un tweet:", mean(tmp_tw$nlikes), "\n")
  cat("Num. di risposte medie a un tweet:", mean(tmp_tw$nreplies), "\n")
  cat("Num. di retweet medi per un tweet:", mean(tmp_tw$nretweets), "\n")
  # like, reply, retweet (mediana)
  cat("\n")
  cat("Num. di like mediani per un tweet:", median(tmp_tw$nlikes), "\n")
  cat("Num. di risposte mediane per un tweet:", median(tmp_tw$nreplies), "\n")
  cat("Num. di retweet mediani per un tweet:", median(tmp_tw$nretweets), "\n")
  # like, reply, retweet (massimo)
  cat("\n")
  cat("Num. di like massimo per un tweet:", max(tmp_tw$nlikes), "\n")
  cat("Num. di risposte massimo per un tweet:", max(tmp_tw$nreplies), "\n")
  cat("Num. di retweet massimo per un tweet:", max(tmp_tw$nretweets), "\n")
  # hashtags
  cat("\n")
  cat("Numero di hashtag usati:", sum(tmp_tw$hashtags_count), "\n")
  cat("Numero di hashtag medi per tweet:", mean(tmp_tw$hashtags_count), "\n")
  cat("Numero di hashtag mediano per tweet:", median(tmp_tw$hashtags_count), "\n")
  cat("\n------------------------------------------------\n\n")
}

# ---------------------------------------------------------------------------- #

# Numero di tweet per ogni politico per ogni partito

# Lega
ntweets <- sapply(unique(tw$username[tw$partito == "LSP"]), function(x) length(tw$tweet[tw$username == x]))
data <- as.data.frame(sort(ntweets, decreasing = T))
data$nomi <- rownames(data)
colnames(data) <- c("ntweets", "nomi")

img_LSP <- data %>%
  mutate(name = fct_reorder(nomi, desc(ntweets))) %>%
  ggplot( aes(x = name, y = ntweets)) + ylim(0,8500) +
  geom_bar(stat="identity", fill="#f68060", alpha=.6, width=.4) +
  coord_flip() + 
  xlab("") + ggtitle("Lega per Salvini Premier") +
  theme_bw()

# Fradelli d'Italia
ntweets <- sapply(unique(tw$username[tw$partito == "FdI"]), function(x) length(tw$tweet[tw$username == x]))
data <- as.data.frame(sort(ntweets, decreasing = T))
data$nomi <- rownames(data)
colnames(data) <- c("ntweets", "nomi")

img_FdI <- data %>%
  mutate(name = fct_reorder(nomi, desc(ntweets))) %>%
  ggplot( aes(x = name, y = ntweets)) + ylim(0,8500) +
  geom_bar(stat="identity", fill="#f68060", alpha=.6, width=.4) +
  coord_flip() +
  xlab("") + ggtitle("Fratelli d'Italia") +
  theme_bw()

## Forza Italia
ntweets <- sapply(unique(tw$username[tw$partito == "FI"]), function(x) length(tw$tweet[tw$username == x]))
data <- as.data.frame(sort(ntweets, decreasing = T))
data$nomi <- rownames(data)
colnames(data) <- c("ntweets", "nomi")

img_FI <- data %>%
  mutate(name = fct_reorder(nomi, desc(ntweets))) %>%
  ggplot( aes(x = name, y = ntweets)) + ylim(0,8500) +
  geom_bar(stat="identity", fill="#f68060", alpha=.6, width=.4) +
  coord_flip() + ggtitle("Forza Italia") +
  xlab("") +
  theme_bw()

## Italia Viva
ntweets <- sapply(unique(tw$username[tw$partito == "IV"]), function(x) length(tw$tweet[tw$username == x]))
data <- as.data.frame(sort(ntweets, decreasing = T))
data$nomi <- rownames(data)
colnames(data) <- c("ntweets", "nomi")

img_iv <- data %>%
  mutate(name = fct_reorder(nomi, desc(ntweets))) %>%
  ggplot( aes(x = name, y = ntweets)) + ylim(0,8500) +
  geom_bar(stat="identity", fill="#f68060", alpha=.6, width=.4) +
  coord_flip() + ggtitle("Italia Viva") +
  xlab("") +
  theme_bw()

## Partito Democratico
ntweets <- sapply(unique(tw$username[tw$partito == "PD"]), function(x) length(tw$tweet[tw$username == x]))
data <- as.data.frame(sort(ntweets, decreasing = T))
data$nomi <- rownames(data)
colnames(data) <- c("ntweets", "nomi")

img_PD <- data %>%
  mutate(name = fct_reorder(nomi, desc(ntweets))) %>%
  ggplot( aes(x = name, y = ntweets)) + ylim(0,8500) +
  geom_bar(stat="identity", fill="#f68060", alpha=.6, width=.4) +
  coord_flip() + ggtitle("Partito Democratico") +
  xlab("") +
  theme_bw()

## Movimento 5 Stelle
ntweets <- sapply(unique(tw$username[tw$partito == "M5S"]), function(x) length(tw$tweet[tw$username == x]))
data <- as.data.frame(sort(ntweets, decreasing = T))
data$nomi <- rownames(data)
colnames(data) <- c("ntweets", "nomi")

img_M5S <- data %>%
  mutate(name = fct_reorder(nomi, desc(ntweets))) %>%
  ggplot( aes(x = name, y = ntweets)) + ylim(0,8500) +
  geom_bar(stat="identity", fill="#f68060", alpha=.6, width=.4) +
  coord_flip() + ggtitle("Fratelli d'Italia") +
  xlab("") + ggtitle("MoVimento 5 Stelle") +
  theme_bw()

grid.arrange(img_LSP, img_FdI, img_FI, img_iv, img_PD, img_M5S, nrow = 3)

# ---------------------------------------------------------------------------- #

# Considero solo i tweet originali, non le risposte ad altri tweet
tw <- tw[tw$reply_to==0,]

# ---------------------------------------------------------------------------- #

tw$hour[tw$hour==0] <- 24
tw$hour[tw$hour==1] <- 25
tw$hour[tw$hour==2] <- 26

k <- table(tw$hour, tw$partito) %>% prop.table(2) 
k_Means <- data.frame("hour" = 3:26, "partito" = rep("Means", 24), "Freq" = rowMeans(k) )
k <- as.data.frame(k)
colnames(k) <- c("hour", "partito", "Freq")
k <- rbind(k, k_Means)
p_f_rel <- k %>% subset(partito %in% unique(partito)[-7]) %>%
  ggplot(aes(x=hour, y=Freq, group=partito, color=partito)) +
  geom_line() +
  geom_line(aes(x = hour, y = Freq, color = "Media"), colour = "black", lwd = 1.2, data = k[k$partito == "Means",]) +
  theme(legend.position = "bottom") + ylab("Frequenza relativa") +
  scale_x_discrete(name ="Time", 
                   labels = c("3" = "3", 
                              "4" = "4", 
                              "5" = "5", 
                              "6" = "6", 
                              "7" = "7",
                              "8" = "8", 
                              "9" = "9", 
                              "10" = "10", 
                              "11" = "11", 
                              "12" = "12", 
                              "13" = "13", 
                              "14" = "14",
                              "15" = "15", 
                              "16" = "16", 
                              "17" = "17", 
                              "18" = "18", 
                              "19" = "19", 
                              "20" = "20", 
                              "21" = "21", 
                              "22" = "22", 
                              "23" = "23", 
                              "24" = "0", 
                              "25" = "1", 
                              "26" = "2"))

p_f_rel
# ---------------------------------------------------------------------------- #

# ---------------------------------------------------------------------------- #

# Analisi:
# - Network of Words sugli stem (rete di unigrammi)
# - Clustering attraverso Louvain, applicato alla Network of Words
# - Interpretazione delle comunita' guardando le parole pi�� importanti
# - Selezione del 10% di parole piu' importanti per comunita' (maggior degree)
# - Analisi delle corrispondenze lessicali (LCA) per partito con solo le parole pi�� importanti
# - Clustering applicato alle coordinate colonna della LCA

# ---------------------------------------------------------------------------- #

rm(list=ls())
load("data/02_tweets_stem.RData")
# Considero solo i tweet originali, non le risposte ad altri tweet
tw <- tw[tw$reply_to==0,]

# ---------------------------------------------------------------------------- #

### Network of Words

# Preparo dataframe per la rete
tt <-  tw %>% select(tweet=tweet_stem, partito=partito) %>% mutate(id = 1:n())
tt <- tt %>% unnest_tokens(word, tweet) %>% group_by(id,word) %>% mutate(freq = n())
X <- tt %>% cast_sparse(row=id, column=word, value=freq)
nomi <- colnames(X)
# Rimuovo gli hapax
del <- which(colSums(X)<=1)
X <- X[,-del]
colnames(X) <- nomi[-del]
dim(X)  # 34641 13307

# Costruisco matrice parole x parole, ogni suo elemento e' una sorta di distanza
# che misura quante volte due parole distinte compaiono nello stesso documento 
M <- t(X) %*% X
dim(M)  # 13307 x 13307

# Costruisco la rete di unigrammi
g <- graph_from_adjacency_matrix(M, weighted=T, mode="undirected", add.rownames=T)
# Rimuovo i self loops poiche' non d'interesse; in teoria non serve
g <- simplify(g, remove.loops=T)
# Tengo solo la rete completamente connessa piu' grande; in realta', si ha gia'
# una rete completamente connessa, quindi e' un comando balzabile
table(components(g)$membership)
g <- delete_vertices(g, which(components(g)$membership != 1)) 
# g ha 13307 nodi/stem e 1686027  archi/co-occorrenze

# ---------------------------------------------------------------------------- #

### Clustering: Metodo di Louvain

gr <- cluster_louvain(graph=g)
table(gr$membership)
#    1    2    3    4    5 
# 1922 4189 3103 3045 1048 

# Ho identificato 7 gruppi: costruisco una nuova sotto-rete per ogi comunita' e 
# identifico il 10% delle parole piu' importanti
ris = c()
top50_words_by_community <- c()
for(i in 1:length(unique(gr$membership))){
  cat(i, "- ")
  Xi = tt[tt$word %in% gr$names[gr$membership==i],] %>% cast_sparse(row=id, column=word, value=freq)
  M <- t(Xi) %*% Xi
  g <- graph_from_adjacency_matrix(M, weighted=T, mode="undirected",add.rownames=T)
  g <- simplify(g, remove.loops=T)
  cat(dim(Xi)[2], "x 0.1=", dim(Xi)[2]*0.1, "\n")
  top50_words_by_community <- cbind(top50_words_by_community,
                                    names(sort(degree(g),decreasing=T))[1:50])
  ris <- c(ris, names(sort(degree(g), decreasing = T)[1:(dim(Xi)[2]*0.1)]))
}
# In totale, gli stem importanti sono 1327 di cui 29 emote
length(ris)                # 1328 stem
sum(grepl("emote_", ris))  #   23 emote

# Nella variabile 'top50_words_by_community' ho salvato i 50 nodi/stem con maggior
# degree per comunita'; li utilizzo per associare dei topic:
#  - Gruppo 1 n: 1922 - Dirette su facebook, appuntamenti
#  - Gruppo 2 n: 4189 - violenza sulle donne, auguri, principi astratti
#  - Gruppo 3 n: 3103 - Manovre economico - politiche per l'emergenza
#  - Gruppo 4 n: 3045 - politica interna
#  - Gruppo 5 n: 1048 - Tweet su Roma e altre cose sconnesse
top50_words_by_community

xtable(top50_words_by_community)

# ---------------------------------------------------------------------------- #

### Analisi delle Corrispondenze Lessicali per partito

# Costruisco una nuova matrice che considera tutti i tweet di un partito come un
# unico documento; cosi' facendo avro' una matrice 6 x 22641 
create_X_partito <- function(tweet) {
  # Funzione per considerare tutti i tweet di un partito come un'unico testo e 
  # costruire la corrispondente matrice doc x stem
  tt =  tweet %>% select(tweet=tweet_stem, partito=partito, utente=username) %>% mutate(id = 1:n())
  tt = tt %>% unnest_tokens(word,tweet) %>% group_by(id,word) %>% mutate(freq=n())
  tt = tt %>% group_by(partito,word) %>% mutate(freq=sum(freq))
  X = tt %>% cast_sparse(row=partito, column=word, value=freq)
  cat("Dimensioni X:", dim(X), "\n")
  return(X)
}

X_partito <- create_X_partito(tw)
sum(colSums(X_partito) == 1)     # 9334 hapax (compaiono una volta in tutto il corpus)
sum(colSums(X_partito > 1) == 1) # 5080 stem che compaiono solo in un partito
max(X_partito)                   # 2582 �� la frequenza pi�� alta

# Distribuzione delle frequenze assolute degli stem nel corpus (DA SISTEMARE)
hist(colSums(X_partito), nclass = 100, xlim = c(0,500), freq = F)
lines(density(colSums(X_partito)), col = 2, lwd = 2)

# La matrice 'X_partito' contiene tutti gli stem: elimino tutti quelli che non
# sono presenti in 'ris', ovvero non sono tra il 10% delle parole pi�� usate in
# ogni gruppo
dataM <- as.matrix(X_partito[, colnames(X_partito) %in% ris])
dim(dataM) #  6 partiti x 1328 stem
colnames(dataM)[colSums(dataM) == 1] # 0 nessun hapax
sum(rowSums(dataM) == 0) # 0, nessun partito risulta non rappresentato

# Osservo che 17 stem che compaiono solo in un partito sono utilizzati da un 
# solo partito: vado a vedere le parole
sum(colSums(dataM > 1) == 1)              # 17
colnames(dataM)[colSums(dataM > 1) == 1]  # stem dei tweet di forza italia

# Distribuzione delle frequenze assolute degli stem nel corpus (DA SISTEMARE)
hist(colSums(dataM), nclass=100, xlim=c(0, 1000), freq=F)

# ---------------------------------------------------------------------------- #

# Ora posso usare la LCA:
#  - graph=T mette sia i punti riga sia i punti colonna ma fa cagare perch�� ci
#    sono troppe parole (1328)
res.ca <- CA(dataM, graph=FALSE)

# Faccio il plot solo dei punti riga perche' mi interessano i partiti 
fviz_ca_row(res.ca, repel=TRUE)

# Se considero la prima dimensione:
#   - FI, PD, IV molto vicine, allo stesso livello praticamente
#   - M5S e LSP agli estremi
#   - FdI intermedio tra LSP e il gruppetto di 3
# Se considero la seconda dimensione:
#   - gruppetto di tre da soli all'estremo negativo
#   - LSP e M5S allo stesso livello positivo 

# Stesso plot ma con colori associati ai punti; il colore e' definito in base a 
# l'indice di qualita 'cos2' (cos2 elevato => buono)
fviz_ca_row(res.ca, col.row = "cos2",
            gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"), 
            repel = TRUE)
# note:
#  - valore di cos2 per una data dimensione somma 1, quindi il valore associato
#    a un punto riga (partito) indica quanto e' utile il partito per definire la
#    dimensione latente
#  - e' coerente con i contributi dei partiti sulle prime due dimensioni
#  - somma del coseno al quadrato di quella riga delle prime due dim -> infatti PD e FI sono rossi

# Grafico 'cos2' righe per la prima dimensione:
#  - M5S e Lega danno i maggiori contributi per la prima dimensione
fviz_contrib(res.ca, choice="row", axes=1, top=10)
# Grafico 'cos2' righe per la seconda dimensione:
#  - Lega e IV danno i maggiori contributi per la prima dimensione
fviz_contrib(res.ca, choice = "row", axes = 2, top = 10)

# Ottengo gli eigenvalue/autovalori per vedere quanta variabilita' dei dati ogni
# dimensione riesce a spiegare
eig.val <- get_eigenvalue(res.ca)
eig.val
#        eigenvalue variance.percent cumulative.variance.percent
# Dim.1 0.16581765         36.90072                    36.90072
# Dim.2 0.12362469         27.51119                    64.41191
# Dim.3 0.06385366         14.20986                    78.62177
# Dim.4 0.05088160         11.32309                    89.94486
# Dim.5 0.04518395         10.05514                   100.00000

# Da notare che il numero massimo di dimensioni e' 5, ovvero n-1; il seguente
# comando mostra in maniera intuitiva il contributo di ogni dimensione
fviz_screeplot(res.ca, addlabels=TRUE, ylim = c(0, 50))

# Contributi dei partiti sulle dimensioni
row<- get_ca_row(res.ca)
row$contrib
#            Dim 1     Dim 2       Dim 3      Dim 4      Dim 5
# M5S 7.071378e+01 16.55558256 3.564965e-08  0.5117973  0.121885499
# LSP 2.462886e+01 38.59361094 1.129607e+01  1.0299395  0.002075495
# PD  3.399837e-01  9.87173160 6.038086e-01  3.8148092 72.944357591
# FI  5.185253e-04  7.94538965 9.290830e+00 47.8652086 16.802116228
# FdI 4.284376e+00  0.07139244 5.555907e+01 26.1046307  0.314078484
# IV  3.248748e-02 26.96229281 2.325022e+01 20.6736146  9.815486703
#primo fattore PD, FdI, IV e M5S, secondo FI, FdI


# Contributi degli stem sulle dimensioni: visto che sono tanti, vado a vedere
# solo i primi 50 per ogni dimenzione
col <- get_ca_col(res.ca)
k <- 50
stem_contributi_CA <- matrix(NA, ncol=5, nrow=k)
colnames(stem_contributi_CA) <- paste("Dimensione", as.factor(1:5))
stem_contributi_CA[,1] <- cbind(names(sort(col$contrib[,1], decreasing = T)[1:k]))
stem_contributi_CA[,2] <- cbind(names(sort(col$contrib[,2], decreasing = T)[1:k]))
stem_contributi_CA[,3] <- cbind(names(sort(col$contrib[,3], decreasing = T)[1:k]))
stem_contributi_CA[,4] <- cbind(names(sort(col$contrib[,4], decreasing = T)[1:k]))
stem_contributi_CA[,5] <- cbind(names(sort(col$contrib[,5], decreasing = T)[1:k]))

stem_contributi_CA

# ---------------------------------------------------------------------------- #

# Guardo le 20 parole che forniscono un maggior contributo alla prima dimensione (cos2)
fviz_contrib(res.ca, choice="col", axes=1, top=20)
# emote_star e salvini sono i primi due, ma sono livelli molto bassi eccetto per il primo

# Guardo le 20 parole che forniscono un maggior contributo alla seconda dimensione (cos2)
fviz_contrib(res.ca, choice="col", axes=2, top=20)
# contributi pi�� distribuiti su tutte le parole: emote_star e salvini le prime

# ---------------------------------------------------------------------------- #

### Clustering delle parole sulle coordinate colonna

# Dai grafici delle prime due dimensioni sembrano esserci tre gruppi, tuttavia
# il grafico e' un'approssimazione poiche' considera sole prime due dimensioni 
# che insieme spiegano solo il 63% della variabilita'.

# Per verificare la presenza di gruppi, utilizzo metodi di clustering vari:
# se ottengo sempre risultati simili, posso concludere che esistono dei cluster

# HCPC
hc <- HCPC(res.ca, nb.clust=-1)
fviz_dend(hc, show_labels=T)

# Grafico 3D
#plot(hc, choice="3D.map")

# Riporto fianco a fianco il dendogramma e il clustering
CA_ggplot <- fviz_ca_row(res.ca, repel=TRUE)
library(cowplot)
plot_grid(fviz_ca_row(res.ca, repel = TRUE),
          fviz_dend(hc, show_labels=T),
          ncol = 2)

# ---------------------------------------------------------------------------- #

# Individuals factor map: grafico bellino per indicare i gruppi, riporta anche i centroidi
fviz_cluster(hc, geom = "point", main = "Factor map")

# ---------------------------------------------------------------------------- #

# Metodi gerarchici
seed.dist <- dist(res.ca$row$coord, method="euclidean") # matrice di distanze
hcc <- hclust(seed.dist, method="complete")
plot(hcc)
rect.hclust(hcc, k=3, border="red") # m5S per i fatti suoi e poi altri due gruppi

# Metodo agglomerativo AGNES
ag <- agnes(res.ca$row$coord, metric="euclidean", method="average", trace.lev=1)
ag
plot(ag, which.plots=2, main="Metodo agglomerativo AGNES")

# Metodo divisivo DIANA
da <- diana(res.ca$row$coord, metric="euclidean", trace.lev=1)
da
plot(da, which.plots=2, main="Metodo divisivo DIANA")

# ---------------------------------------------------------------------------- #

# Tutti i metodi di clustering sono coerenti e uguali nei risultati; anche
# considerando tutte e 5 le dimensioni si conferma quanto visto con 2:
#     - M5S da solo isolato
#     - LSP, FdI insieme
#     - PD, FI, IV insieme con gli ultimi due maggiormente legati

# Come interpreto questi tre gruppi? 
# Sto raggruppando usando le parole che utilizzano, quindi si raggruppano in base a come si esprimono
#     - LSP e FdI sono partiti monoesponente: Salvini da una parte e Crosetto dall'altra.
#     - M5S invece punta sul movimento nell'insieme e non sul singolo.

# Attenzioni:
# LSP e FdI non hanno la pagina del partito, mentre M5S ha solo pagina del partito.
# Potrebbe essere un motivo della separazione cos�� netta tra quei partiti.

# ---------------------------------------------------------------------------- #

# LDA

# ---------------------------------------------------------------------------- #

rm(list=ls())
load("data/02_tweets_stem.RData")
tw <- tw[tw$reply_to==0,]

# ---------------------------------------------------------------------------- #

tt <- tw %>% select(tweet=tweet_stem, partito=partito, username = username) %>% mutate(id = 1:n())
tt2 <- tt %>% unnest_tokens(word,tweet) %>% group_by(id,word) %>% mutate(freq=n())
X <- tt2 %>% cast_sparse(row=id, column=word, value=freq)

# Creo il vettore partito
vettore_partito <- tt$partito[as.numeric(rownames(X))]
dim(X)[1]==length(vettore_partito)
table(vettore_partito)
#  FdI   FI   IV  LSP  M5S   PD 
# 4571 6151 7667 8471 3601 4180 

# Filtro le colonne, o meglio rimuovo gli hapax
nomi <- colnames(X)
del <- which(Matrix::colSums(X)<=1)
X <- X[, -del]
colnames(X) <- nomi[-del]

# Filtro X e vettore_partito rimuovendo i tweet senza stem
vettore_partito <- vettore_partito[Matrix::rowSums(X)>0]
X <- X[Matrix::rowSums(X)>0,]
dim(X)[1]==length(vettore_partito)
table(vettore_partito)
#  FdI   FI   IV  LSP  M5S   PD 
# 4566 6151 7667 8470 3601 4177 
dim(X)  # 34632 13307

# ---------------------------------------------------------------------------- #

# Ora posso stimare la LDA con 7 topic (e' la migliore tra 5, 6, 7 e 8)
q_lda <- LDA(as.matrix(X), k=5, method="Gibbs", control=list(seed=123,
                                                             burnin=1000,
                                                             iter=5000))
beta_topics <- tidy(q_lda, matrix="beta")
dim(beta_topics) # 66535 x 3     nota: 66535 = k*V = 5*13307

# Per ogni topic selezione i 10 termini con peso maggiore, ovvero scelgo i 
# termini a cui corrispondono i valori piu' alti dei parametri beta
termini <- beta_topics %>% group_by(topic) %>% top_n(20, beta) %>% arrange(topic)
# Sostituisco le stringhe degli emote con la vera emote
term_pl <- termini %>% ungroup %>% mutate(term=reorder(term,beta))
term_pl$term <- as.character(term_pl$term)
term_pl$term[term_pl$term=="emote_backhand_index_pointing_right"] <- "�9�7"
term_pl$term[term_pl$term=="emote_italy"] <- "�9�4�9�5"
term_pl$term[term_pl$term=="emote_red_circle"] <- "�9�2"
term_pl$term <- as.factor(term_pl$term)
term_pl <- term_pl %>% mutate(term=reorder(term,beta))

# Rapppresento graficamente questi termini
plot_base <- ggplot(term_pl, aes(term, beta, fill=factor(topic))) +
  geom_col() + facet_wrap(~topic, scales="free", nrow=1)
plot_base + theme(legend.position="none") + coord_flip()

# ---------------------------------------------------------------------------- #

# Per ogni topic ottengo i 50 stem piu' importanti e metto tutto in tabella
top_50_words <- beta_topics %>% group_by(topic) %>% top_n(50, beta) %>%
  arrange(topic) %>% ungroup %>% mutate(term=reorder(term,beta)) 
t_table <- c()
for (j in 1:5) {
  tmp_list <- as.data.frame(top_50_words[top_50_words$topic==j,])
  tmp_list$term <- as.character(tmp_list$term)
  t_table <- cbind(t_table, tmp_list[order(tmp_list$beta,decreasing=T),2])
}
t_table

# ---------------------------------------------------------------------------- #

# Costruisco la matrice gamma a partire da gamma_doc
gamma_doc <- tidy(q_lda, matrix="gamma")
gamma <- vettore_partito
for (j in 1:max(gamma_doc$topic)) {
  gamma <- cbind(gamma, gamma_doc[gamma_doc$topic==j,"gamma"])
}
colnames(gamma) <-  c("partito", "t1", "t2", "t3", "t4", "t5")
dim(gamma) # 34641 x 6  (n x k+1)

# ---------------------------------------------------------------------------- #

# Ottengo colori utilizzati da ggplot
gg_color_hue <- function(n) {
  hues = seq(15, 375, length = n + 1)
  hcl(h = hues, l = 65, c = 100)[1:n]
}
gg_colors <- gg_color_hue(6)
plot(1:5, pch=16, cex=2, col=gg_colors)

# ---------------------------------------------------------------------------- #


# Traccio grafico con le distr. dei topic per un fissato partito
gg_colors <- gg_color_hue(5)
for (p in partito_list) {
  post_tmp <- gamma[gamma$partito==p,-1]
  # Costruisco grafico
  p_tmp <- ggplot(post_tmp, aes(x=t1)) + xlim(0.1, 0.45) + ylim(0, 20) +
    stat_density(geom="line",position="identity", aes(x=t1), color=gg_colors[1], lwd=0.8, data=post_tmp) +
    stat_density(geom="line",position="identity", aes(x=t2), color=gg_colors[2], lwd=0.8, data=post_tmp) +
    stat_density(geom="line",position="identity", aes(x=t3), color=gg_colors[3], lwd=0.8, data=post_tmp) +
    stat_density(geom="line",position="identity", aes(x=t4), color=gg_colors[4], lwd=0.8, data=post_tmp) +
    stat_density(geom="line",position="identity", aes(x=t5), color=gg_colors[5], lwd=0.8, data=post_tmp) +
    geom_vline(xintercept=mean(post_tmp[,1]), linetype="dashed", color=gg_colors[1], size=0.8) +
    geom_vline(xintercept=mean(post_tmp[,2]), linetype="dashed", color=gg_colors[2], size=0.8) +
    geom_vline(xintercept=mean(post_tmp[,3]), linetype="dashed", color=gg_colors[3], size=0.8) +
    geom_vline(xintercept=mean(post_tmp[,4]), linetype="dashed", color=gg_colors[4], size=0.8) +
    geom_vline(xintercept=mean(post_tmp[,5]), linetype="dashed", color=gg_colors[5], size=0.8) +
    xlab(p) + ylab("Densit��") + theme(legend.position="none")
  # Creo tabella contenente valore atteso e varianza per ogni topic
  table_tmp <- cbind(1:5,
                     format(round(apply(post_tmp, 2, mean), 4),nsmall=2),
                     format(round(apply(post_tmp, 2, sd), 4),nsmall=2))
  table_tmp <- rbind(c("topic", "mean", "sd"), table_tmp)
  # Aggiungo la tabella al grafico come legenda
  grob_t1 <- ttheme_minimal(core=list(bg_params=list(fill=c("white",gg_colors[1:5]),col=NA)))
  table_tmp_grob <- tableGrob(table_tmp, theme=grob_t1, rows=NULL)
  table_tmp_grob <- gtable_add_grob(table_tmp_grob,
                                    grobs=rectGrob(gp=gpar(fill=NA, lwd=1)),
                                    t=1, b=nrow(table_tmp_grob), l=1, r=ncol(table_tmp_grob))
  # Unisco grafico e tabella
  pp_tmp <- arrangeGrob(p_tmp, table_tmp_grob, nrow=1, ncol=2, widths=c(4,1))
  # Salvo grafico
  ggsave(pp_tmp, filename=paste("lda_density_",p,".png",sep=""), device="png")
}

# ---------------------------------------------------------------------------- #

# Traccio grafico con le distr. dei partiti per un fissato topic
gg_colors <- gg_color_hue(6)
t_dict <- list("t1"="Topic 1","t2"="Topic 2","t3"="Topic 3","t4"="Topic 4","t5"="Topic 5")
for (t in c("t1","t2","t3","t4","t5")) {
  # Creo tabella contenente valore atteso e varianza per ogni topic
  means_tmp <- c(mean(gamma[gamma$partito==partito_list[1],t]),
                 mean(gamma[gamma$partito==partito_list[2],t]),
                 mean(gamma[gamma$partito==partito_list[3],t]),
                 mean(gamma[gamma$partito==partito_list[4],t]),
                 mean(gamma[gamma$partito==partito_list[5],t]),
                 mean(gamma[gamma$partito==partito_list[6],t]))
  sd_tmp <- c(sd(gamma[gamma$partito==partito_list[1],t]),
              sd(gamma[gamma$partito==partito_list[2],t]),
              sd(gamma[gamma$partito==partito_list[3],t]),
              sd(gamma[gamma$partito==partito_list[4],t]),
              sd(gamma[gamma$partito==partito_list[5],t]),
              sd(gamma[gamma$partito==partito_list[6],t]))
  table_tmp <- cbind(partito_list,
                     format(round(means_tmp, 4),nsmall=4),
                     format(round(sd_tmp, 4),nsmall=4))
  table_tmp <- rbind(c("partito", "mean", "sd"), table_tmp)
  colnames(table_tmp) <- NULL
  # Costruisco grafico
  p_tmp <- ggplot(gamma, aes(x=!!ensym(t))) + xlim(0.1, 0.45) + ylim(0, 20) +
    stat_density(geom="line",position="identity", aes(x=!!ensym(t)), color="#000000", lwd=1.0, data=gamma) +
    stat_density(geom="line",position="identity", aes(x=!!ensym(t)), color=gg_colors[1], lwd=0.8, data=gamma[gamma$partito==partito_list[1],-1]) +
    stat_density(geom="line",position="identity", aes(x=!!ensym(t)), color=gg_colors[2], lwd=0.8, data=gamma[gamma$partito==partito_list[2],-1]) +
    stat_density(geom="line",position="identity", aes(x=!!ensym(t)), color=gg_colors[3], lwd=0.8, data=gamma[gamma$partito==partito_list[3],-1]) +
    stat_density(geom="line",position="identity", aes(x=!!ensym(t)), color=gg_colors[4], lwd=0.8, data=gamma[gamma$partito==partito_list[4],-1]) +
    stat_density(geom="line",position="identity", aes(x=!!ensym(t)), color=gg_colors[5], lwd=0.8, data=gamma[gamma$partito==partito_list[5],-1]) +
    stat_density(geom="line",position="identity", aes(x=!!ensym(t)), color=gg_colors[6], lwd=0.8, data=gamma[gamma$partito==partito_list[6],-1]) +
    geom_vline(xintercept=mean(gamma[,t]), linetype="dashed", color="black", size=1.0) +
    geom_vline(xintercept=means_tmp[1], linetype="dashed", color=gg_colors[1], size=0.8) +
    geom_vline(xintercept=means_tmp[2], linetype="dashed", color=gg_colors[2], size=0.8) +
    geom_vline(xintercept=means_tmp[3], linetype="dashed", color=gg_colors[3], size=0.8) +
    geom_vline(xintercept=means_tmp[4], linetype="dashed", color=gg_colors[4], size=0.8) +
    geom_vline(xintercept=means_tmp[5], linetype="dashed", color=gg_colors[5], size=0.8) +
    geom_vline(xintercept=means_tmp[6], linetype="dashed", color=gg_colors[6], size=0.8) +
    xlab(t_dict[[t]]) + ylab("Densit��") + theme(legend.position="none")
  # Aggiungo la tabella al grafico come legenda
  grob_t1 <- ttheme_minimal(core=list(bg_params=list(fill=c("white",gg_colors[1:6]),col=NA)))
  table_tmp_grob <- tableGrob(table_tmp, theme=grob_t1, rows=NULL)
  table_tmp_grob <- gtable_add_grob(table_tmp_grob,
                                    grobs=rectGrob(gp=gpar(fill=NA, lwd=1)),
                                    t=1, b=nrow(table_tmp_grob), l=1, r=ncol(table_tmp_grob))
  # Unisco grafico e tabella
  pp_tmp <- arrangeGrob(p_tmp, table_tmp_grob, nrow=1, ncol=2, widths=c(4,1))
  # Salvo grafico
  ggsave(pp_tmp, filename=paste("lda_density_",t,".png",sep=""), device="png")
}

# ---------------------------------------------------------------------------- #
